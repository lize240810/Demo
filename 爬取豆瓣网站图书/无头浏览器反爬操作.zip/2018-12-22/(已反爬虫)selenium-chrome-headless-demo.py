# -*- coding: utf-8 -*-
import os
from pprint import pprint
import json

from pyquery import PyQuery
from selenium import webdriver


options.add_argument("--headless")  # 在无头模式下运行Chrome.
options.add_argument('--no-sandbox')  # 绕过安全模式
options.add_argument('--disable-gpu')  # 只适用与windows 精致gpu渲染
options.add_argument('disable-infobars') # 禁止
options.add_argument("--disable-plugins-discovery") # 禁止插件加载
user_agent = "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.67 Safari/537.36"
options.add_argument('user-agent="{0}"'.format(user_agent)) # 设置浏览器头
options.add_argument('--remote-debugging-port=9222') #
# options.add_argument('start-maximized') # 禁止最大化
# options.add_argument("--disable-extensions") # 禁止扩展栏

# 添加忽略证书错误
options.add_experimental_option("excludeSwitches", ["ignore-certificate-errors"])

if '__file__' not in globals():
    __file__ = 'elenium-chrome-headless-demo.py'
driver_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), r'chromedriver.exe')

# [------------------- 不要读我，我是用来干掉反扒的，拿来直接用-第一部分 ------------------------
def send(driver, cmd, params={}):
    '''
    向调试工具发送指令
    from: https://stackoverflow.com/questions/47297877/to-set-mutationobserver-how-to-inject-javascript-before-page-loading-using-sele/47298910#47298910
    '''
    resource = "/session/%s/chromium/send_command_and_get_result" % driver.session_id
    url = driver.command_executor._url + resource
    body = json.dumps({'cmd': cmd, 'params': params})
    response = driver.command_executor._request('POST', url, body)
    if response['status']:
        raise Exception(response.get('value'))
    return response.get('value')

def add_script(driver, script):
    '''在页面加载前执行js'''
    send(driver, "Page.addScriptToEvaluateOnNewDocument", {"source": script})

# 给 webdriver.Chrome 添加一个名为 add_script 的方法
webdriver.Chrome.add_script = add_script # 这里（webdriver.Chrome）可能需要改，当调用不同的驱动时
# 第一部分，需要在浏览器初始化(举例： browser = webdriver.Chrome())之前
# ------------------- 不要读我，我是用来干掉反扒的，拿来直接用-第一部分 ------------------------]

browser = webdriver.Chrome(executable_path=driver_path, chrome_options=options)

# 已经存在的信息
existed = {
    'executor_url': browser.command_executor._url,  # 浏览器可被远程连接调用的地址
    'session_id': browser.session_id  # 浏览器会话ID
}
pprint(existed)
# 把 已经存在的信息 写入到json文件(目的: 为了方便以 -existed.py 结尾的两个文件，不用复制粘贴，直接从json读取)
with open('existed.json', 'wt', encoding='utf-8') as f:
    json.dump(existed, f, ensure_ascii=False, indent=4)

# [------------------- 不要读我，我是用来干掉反扒的，拿来直接用-第二部分 ------------------------
# 参考:
# 如何解决selenium被检测，实现淘宝登陆：  https://www.urlteam.org/2018/11/如何解决selenium被检测，实现淘宝登陆/
# 反爬虫中chrome无头浏览器的几种检测与绕过方式： https://blog.csdn.net/Revivedsun/article/details/81785000
# IT IS *NOT* POSSIBLE TO DETECT AND BLOCK CHROME HEADLESS： https://intoli.com/blog/not-possible-to-block-chrome-headless/
# https://developer.mozilla.org/zh-CN/docs/Web/JavaScript/Reference/Global_Objects/Object/defineProperty
browser.add_script("""
Object.defineProperty(navigator, 'webdriver', {
    get: () => false,
});
window.navigator.chrome = {
    runtime: {},
};
Object.defineProperty(navigator, 'languages', {
    get: () => ['zh-CN', 'zh']
});
Object.defineProperty(navigator, 'plugins', {
    get: () => [0, 1, 2],
});
""")
# 第二部分，需要在浏览器初始化(举例： browser = webdriver.Chrome())之后，页面加载之前(举例： browser.get())执行
# ------------------- 不要读我，我是用来干掉反扒的，拿来直接用-第二部分 ------------------------]

browser.get('https://book.douban.com/subject_search?search_text=python&start=30')
doc = PyQuery(browser.page_source)
pprint(doc)

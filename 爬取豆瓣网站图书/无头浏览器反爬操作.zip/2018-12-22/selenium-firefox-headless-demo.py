# -*- coding: utf-8 -*-
import os
import json
from pprint import pprint

from pyquery import PyQuery
from selenium import webdriver


# 火狐选项
options = webdriver.FirefoxOptions()
# options.set_headless(headless=True)  # 设置无头（已被废弃）
options.headless = True  # 设置无头
# 火狐设置
profile = webdriver.FirefoxProfile()
# 禁用图片加载
# 1 - Allow all images
# 2 - Block all images
# 3 - Block 3rd party images 
profile.set_preference('permissions.default.image', 2)
# 忽略证书错误
profile.accept_untrusted_certs = True

if '__file__' not in globals():
    __file__ = 'elenium-firefox-headless-demo.py'
# 驱动路径
driver_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), r'geckodriver.exe')
# 实例化（打开火狐浏览器）
browser = webdriver.Firefox(
    executable_path=driver_path,
    firefox_options=options,
    firefox_profile=profile
)
existed = {
    'executor_url': browser.command_executor._url,
    'session_id': browser.session_id
}
pprint(existed)
# 把 已经存在的信息 写入到json文件(目的: 为了方便以 -existed.py 结尾的两个文件，不用复制粘贴，直接从json读取)
with open('existed.json', 'wt', encoding='utf-8') as f:
    json.dump(existed, f, ensure_ascii=False, indent=4)

browser.get('https://book.douban.com/subject_search?search_text=python&start=30')
doc = PyQuery(browser.page_source)
pprint(doc)

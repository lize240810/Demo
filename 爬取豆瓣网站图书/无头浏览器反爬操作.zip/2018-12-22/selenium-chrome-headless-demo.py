# -*- coding: utf-8 -*-
import os
from pprint import pprint
import json

from pyquery import PyQuery
from selenium import webdriver


options = webdriver.ChromeOptions()
# options.add_argument("--headless") # Runs Chrome in headless mode.
options.add_argument('--no-sandbox') # Bypass OS security model
options.add_argument('--disable-gpu')  # applicable to windows os only
options.add_argument('disable-infobars')
# options.add_argument('start-maximized')
# options.add_argument("--disable-extensions")
# 忽略证书错误(这种方式好像不生效，应该使用add_argument()方式)
options.add_experimental_option("excludeSwitches",["ignore-certificate-errors"])

if '__file__' not in globals():
    __file__ = 'elenium-chrome-headless-demo.py'
# 驱动路径
driver_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), r'chromedriver.exe')
# 实例化(打开浏览器)
browser = webdriver.Chrome(executable_path=driver_path, chrome_options=options)
# 已经存在的信息
existed = {
    'executor_url': browser.command_executor._url,  # 浏览器可被远程连接调用的地址
    'session_id': browser.session_id  # 浏览器会话ID
}
pprint(existed)
# 把 已经存在的信息 写入到json文件(目的: 为了方便以 -existed.py 结尾的两个文件，不用复制粘贴，直接从json读取)
with open('existed.json', 'wt', encoding='utf-8') as f:
    json.dump(existed, f, ensure_ascii=False, indent=4)

# 打开页面
browser.get('https://book.douban.com/subject_search?search_text=python&start=30')
# 读取页面源码，放到PyQuery中，用于解析
doc = PyQuery(browser.page_source)
pprint(doc)

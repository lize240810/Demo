# -*- coding: utf-8 -*-
import time
import json
from pprint import pprint

from selenium import webdriver


existed = None
# 从文件 existed.json 中加载已经存在了的浏览器信息
with open('existed.json', 'rt', encoding='utf-8') as f:
    existed = json.load(f)
pprint(existed)
# 把字典注入到全局变量（键为变量名，值为变量值）
globals().update(existed)
browser = webdriver.Remote(command_executor=executor_url, desired_capabilities={}) #_url为上面的_url
browser.close()  #这时会打开一个全新的浏览器对象, 先把新的关掉
browser.session_id = session_id  #session_id为上面的session_id

# 获取当前窗口句柄
main_window = browser.current_window_handle
# 执行js，在新标签页(Tab)打开一个空页面(about:blank)
browser.execute_script('''window.open("about:blank", "_blank");''')
time.sleep(1)
# （根据窗口句柄）切换到指定的窗口
browser.switch_to_window(main_window)

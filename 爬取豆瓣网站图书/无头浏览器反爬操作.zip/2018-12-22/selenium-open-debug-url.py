# -*- coding: utf-8 -*-
import os
import time
import webbrowser
from pprint import pprint

from selenium import webdriver


options = webdriver.ChromeOptions()
# options.add_argument("--headless")
options.add_argument('--no-sandbox')
options.add_argument('--disable-gpu')
options.add_argument('disable-infobars')
# devtool_port = 54321 # 指定调试工具端口
# options.add_argument('--remote-debugging-port={0}'.format(54321))

if '__file__' not in globals():
    __file__ = 'selenium-open-debug-url.py'
# 驱动路径
driver_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), r'chromedriver.exe')
# 实例化(打开浏览器)
browser = webdriver.Chrome(executable_path=driver_path, chrome_options=options)
# 已经存在的信息
existed = {
    'executor_url': browser.command_executor._url,  # 浏览器可被远程连接调用的地址
    'session_id': browser.session_id  # 浏览器会话ID
}
pprint(existed)

# 获取调试工具地址
devtool_address = browser.capabilities['goog:chromeOptions']['debuggerAddress']
# 打开调试工具URL
webbrowser.get(using='windows-default').open('http://{0}/'.format(devtool_address))

close_delay = 5  # 延迟关闭时间
for i in range(0, close_delay):
    print('{0}分钟后浏览器将自动关闭'.format(close_delay - i))
    time.sleep(60)  # 延时一分钟
# 关闭浏览器
browser.close()

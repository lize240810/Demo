# -*- coding: utf-8 -*-
import time
from pprint import pprint
import json

from selenium import webdriver


existed = None
# 从文件 existed.json 中加载已经存在了的浏览器信息
with open('existed.json', 'rt', encoding='utf-8') as f:
    existed = json.load(f)
# 从字典取得数据，注入到全局变量
globals().update(existed)
# 连接远程的已经存在
browser = webdriver.Remote(
    command_executor=executor_url,  #_url为上面的_url
    desired_capabilities={}
)
browser.close()  # 这时会打开一个全新的浏览器对象, 先把新的关掉
browser.session_id = session_id  #session_id为上面的session_id

# 主窗口句柄
main_handle = browser.current_window_handle

# 枚举所有的窗口（句柄）
for handle in browser.window_handles:
    # 如果不是主窗口句柄
    if handle != main_handle:
        print(handle)
        # 根据句柄切换到这个Tab
        browser.switch_to_window(handle)
        # 关闭当前选项卡(这个选项卡页面)
        browser.close()
# 切换回主窗口
browser.switch_to_window(main_handle)
# 关闭当前选项卡（主窗口）
browser.close()

# -*- coding: utf-8 -*-
import scrapy
import re

from furl import furl
from job_search.items import JobSearchItem
import redis


class JobsSpider(scrapy.Spider):
    name = 'jobs'
    allowed_domains = ['www.bjzph.com']
    start_urls = ['http://www.bjzph.com/']

    def parse(self, response):
        # 去除path
        fu = furl(response.url)
        # 获取到域名
        fu_base = fu.copy().remove(path=True, args=True)
        # 获取到中间件 path 
        path = str(fu.path).strip('/').split('/')[0]

        # 2. 判断当前url路径是否在黑名单里
        client = redis.Redis(host='localhost', port=6379, decode_responses=True)
        # 获取到redis 中的黑名单
        black_value = client.get(path)
        if bool(black_value):
            return None
        # 所有链接
        links = response.xpath('//ul/li/a/@href').extract()
        for url in links:
            # 完整URL
            # 获取路径前缀
            path_prefix = url.strip('/').split('/')[0]
            # 判断是否在黑名单里
            black_value = client.get(path_prefix) 
            # 存在黑名单中就跳过不爬取
            if bool(black_value):
                continue
            # import ipdb as pdb; pdb.set_trace()
            
            # 默认当做列表页面解析
            full_url = fu_base.set(path=url).url
            # 不符合规则继续查询
            callback_func = self.parse
            # 符合规则的url
            if re.search(r'\d\/\d+', full_url):
                # 符合规则进入详细页面
                callback_func = self.parse_detail

                # import ipdb as pdb; pdb.set_trace()        
            # 进入回调函数
            yield scrapy.Request(url=full_url, callback=callback_func)

        # 处理下一页
        next_page = response.xpath('//a[text()[contains(., "下一页")]]/@href')        
        if bool(next_page):
            # 构建完整url
            next_page = fu.copy().add(path=next_page).url  # 构造完整URL
            # 判断当前页是否存在黑名单中     
            path_prefix = next_page.strip('/').split('/')[0]
            # 判断是否在黑名单里
            black_value = client.get(path_prefix) 
            # 存在黑名单中就跳过不爬取
            if bool(black_value):
                return None
            
            yield scrapy.Request(url=next_page, callback=self.parse)


    def parse_detail(self, response):
        fu = furl(response.url)
        path = str(fu.path).strip('/').split('/')[0]  # 只取path前缀
        # 2. 判断当前url路径前缀是否在黑名单里
        client = redis.Redis(host='localhost', port=6379, decode_responses=True)
        black_value = client.get(path)
        if bool(black_value):
            return None
        try:
            # 设置过滤黑名单
            item = JobSearchItem()
            title = response.xpath('//div[@class="title"]/text()').extract_first()
            item['title'] = title
            item['start_time'] = response.xpath('//div[@class="starttime"]/text()').extract_first()
            item['end_time'] = response.xpath('//div[@class="endtime"]/text()').extract_first()
            item['city'] = response.xpath('//div[@class="cityname"]/text()').extract_first()
            item['address'] = response.xpath('//div[@class="address"]/text()').extract_first()
            item['url'] = response.url
            detail = response.xpath('//div[@class="middleLeft"]/p/text()').extract()
            item['detail'] = ''.join(map(lambda item: item.strip(), detail))
        except AttributeError as e:  
            # 如果取不到值，说明这个域名要加到黑名单中              
            client.set(path, 'black')
            print('加到黑名单了' '*' * 1000)
        if not bool(title):
            item = self.parse_optimize(response)
        yield item

        
    def parse_optimize(self, response):
        '''
            页面为空的优化
        '''
        item = JobSearchItem()
        item['title'] = response.xpath('//p[@class="bt"]/text()').extract_first()
        item['start_time'] = response.xpath('//div[@class="jbxx"]/ul/li[4]/text()').extract_first()
        item['end_time'] = None
        item['city'] = response.xpath('//div[@class="jbxx"]/ul/li[2]/text()').extract_first()
        item['address'] = response.xpath('//div[@class="lxfs"]/ul/li[4]/text()').extract_first()
        item['url'] = response.url
        detail = response.xpath('//div[@class="zwyqms"]//p/text()').extract()
        item['detail'] = ''.join(map(lambda item: item.strip(), detail))
        return item

        









        
